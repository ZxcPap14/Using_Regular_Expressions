﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using StringCheckLib;

namespace StringCheckLibTest
{
    /// <summary>
    /// Проверка на правильность написания ФИО
    /// </summary>
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void CheckName_IsEmpty_FalseReturned()
        {
            //Arrange
            string stringname = " ";
            //Act
            bool result = StringCheck.CheckName(stringname);
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void CheckName_IsDash_FalseReturned()
        {
            //Arrange
            string stringname = "-";
            //Act
            bool result = StringCheck.CheckName(stringname);
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void CheckName_UseSymbol_FalseReturned()
        {
            //Arrange
            string stringname = "Казанцев Денис Сергеевич/";
            //Act
            bool result = StringCheck.CheckName(stringname);
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void CheckName_IsTooLong_FalseReturned()
        {
            //Arrange
            string stringname = "КазанцевКазанцевКазанцевКазанцевКазанцев Денис Сергеевич";
            //Act
            bool result = StringCheck.CheckName(stringname);
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void CheckName_UseDigits_FalseReturned()
        {
            //Arrange
            string stringname = "Казанцев1 Денис Сергеевич";
            //Act
            bool result = StringCheck.CheckName(stringname);
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void CheckName_CorrectWriting_TrueReturned()
        {
            //Arrange
            string stringname = "Казанцев Денис Сергеевич";
            //Act
            bool result = StringCheck.CheckName(stringname);
            //Assert
            Assert.IsTrue(result);
        }

    }
}

