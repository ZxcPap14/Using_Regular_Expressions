﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace StringCheckLib
{
    public class StringCheck
    {
        /// <summary>
        /// Проверка stringName на наличие симоволов: Русские буквы, пробел и дефис.
        /// Строка stringName не должна привишать 50 символов.
        /// </summary>
        /// <param name="stringname"></param>
        /// <returns>
        /// true or false
        /// </returns>
        public static bool CheckName(string stringname)
        {
            string regex = @"^(([а-я])|(\s)|(\-))+$";
            string regexWhiteSpace = @"^((\s)|(\-))+$";

            if(stringname.Length>50)
            {
                return false;
            }

            if(Regex.Match(stringname, regexWhiteSpace,RegexOptions.IgnoreCase).Success )
            {
                return false;
            }
            else
            {
                if (Regex.Match(stringname, regex, RegexOptions.IgnoreCase).Success)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
}
